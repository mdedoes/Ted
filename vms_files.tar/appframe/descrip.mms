CC=cc/name=(as_is,short)\
	/include=([],[-.include],[-.appframe],[-.apputil],[-.bitmap],[-.ind])

OBS	=	\
		sioCopyPasteMotif.obj,\
		sioCopyPasteGtk.obj,\
		appZoomMenu.obj,\
		appXvCopyPaste.obj,\
		appWinMetaX11.obj,\
		appWinMetaPs.obj,\
		appWinMetaImg.obj,\
		appWinMeta.obj,\
		appTree.obj,\
		appTextUtil.obj,\
		appTextMotif.obj,\
		appTextGtk.obj,\
		appSymbolPicker.obj,\
		appSpellTool.obj,\
		appRuler.obj,\
		appReally.obj,\
		appQuestion.obj,\
		appPutImageMotif.obj,\
		appPutImageGtk.obj,\
		appPrintDialog.obj,\
		appPaperChooser.obj

OBS1=appPageTool.obj,\
		appOptionmenuMotif.obj,\
		appOptionmenuGtk.obj,\
		appMetricRuler.obj,\
		appMenuMotif.obj,\
		appMenuGtk.obj,\
		appMenu.obj,\
		appMarginTool.obj,\
		appMain.obj,\
		appMailDialog.obj,\
		appMacPictX11.obj,\
		appMacPictPs.obj,\
		appListMotif.obj,\
		appListGtk.obj,\
		appInspectorMotif.obj,\
		appInspectorGtk.obj,\
		appInspector.obj,\
		appImage.obj,\
		appIconsMotif.obj,\
		appIconsGtk.obj,\
		appGuiUtil.obj,\
		appGuiMotif.obj,\
		appGuiGtkX.obj,\
		appGuiGtk.obj,\
		appGetImageMotif.obj,\
		appGetImageGtk.obj,\
		appFontTool.obj,\
		appFont.obj,\
		appFindTool.obj,\
		appFileChooserMotif.obj,\
		appFileChooserGtk.obj,\
		appFileChooser.obj,\
		appEventMotif.obj,\
		appEventGtk.obj,\
		appDrawPage.obj,\
		appDrawMotif.obj,\
		appDrawGtk.obj,\
		appDocumentMotif.obj,\
		appDocumentGtk.obj,\
		appDocument.obj,\
		appDocMetricRuler.obj,\
		appDialogMotif.obj,\
		appDialogGtk.obj,\
		appCopyPasteMotif.obj,\
		appCopyPasteGtk.obj,\
		appColorMotif.obj,\
		appColorGtk.obj

OBS2=appScrollDocument.obj,\
 		appPrintDocument.obj,\
 		appPageLayoutTool.obj,\
 		appEncodingMenu.obj


all : timestamp.vms [-.lib]appFrame.olb
    write sys$output "all done in [.appframe]"

timestamp.vms : config.h_vms
	 copy config.h_vms appFrameConfig.h
	 open/write file timestamp.vms
	 close file

[-.lib]appFrame.olb :	$(OBS) $(OBS1) $(OBS2)
	library/create appFrame.olb $(OBS)
	library appFrame.olb $(OBS1)
	library appFrame.olb $(OBS2)
	rename appFrame.olb [-.lib]

appColorGtk.obj : \
    appColorGtk.c \
    appFrameConfig.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appColorMotif.obj : \
    appColorMotif.c \
    appFrameConfig.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appCopyPasteGtk.obj : \
    appCopyPasteGtk.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appCopyPasteMotif.obj : \
    appCopyPasteMotif.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDialogGtk.obj : \
    appDialogGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appDialogMotif.obj : \
    appDialogMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appDocMetricRuler.obj : \
    appDocMetricRuler.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appMetricRuler.h \
    [-.appFrame]appRuler.h \
    [-.appUtil]appUnit.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDocument.obj : \
    appDocument.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDocumentGtk.obj : \
    appDocumentGtk.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDocumentMotif.obj : \
    appDocumentMotif.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDrawGtk.obj : \
    appDrawGtk.c \
    appFrameConfig.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDrawMotif.obj : \
    appDrawMotif.c \
    appFrameConfig.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDrawPage.obj : \
    appDrawPage.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appGeoString.h

appEncodingMenu.obj : \
    appEncodingMenu.c \
    [-.appFrame]appEncodingMenu.h \
    [-.appFrame]appFrameConfig.h \
    [-.appUtil]psFont.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appEventGtk.obj : \
    appEventGtk.c \
    appFrameConfig.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appEventMotif.obj : \
    appEventMotif.c \
    appFrameConfig.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appFileChooser.obj : \
    appFileChooser.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFileChooser.h

appFileChooserGtk.obj : \
    appFileChooserGtk.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFileChooser.h

appFileChooserMotif.obj : \
    appFileChooserMotif.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFileChooser.h

appFindTool.obj : \
    appFindTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.include]reg.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h

appFont.obj : \
    appFont.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilFontmap.h \
    appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h

appFontTool.obj : \
    appFontTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appGeoString.h \
    [-.appUtil]utilPropMask.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appFontTool.h \
    [-.appFrame]appEncodingMenu.h \
    [-.appFrame]appFrameConfig.h \
    appDraw.h

appGetImageGtk.obj : \
    appGetImageGtk.c \
    appFrameConfig.h \
    [-.appUtil]utilEndian.h \
    [-.appFrame]appImage.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appGetImageMotif.obj : \
    appGetImageMotif.c \
    appFrameConfig.h \
    [-.appUtil]utilEndian.h \
    [-.appFrame]appImage.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appGuiGtk.obj : \
    appGuiGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appGuiGtkX.obj : \
    appGuiGtkX.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appGuiMotif.obj : \
    appGuiMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appGuiUtil.obj : \
    appGuiUtil.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appIconsGtk.obj : \
    appIconsGtk.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    appIcons.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appIconsMotif.obj : \
    appIconsMotif.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    appIcons.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appImage.obj : \
    appImage.c \
    appFrameConfig.h \
    appImage.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appInspector.obj : \
    appInspector.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h

appInspectorGtk.obj : \
    appInspectorGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appInspectorMotif.obj : \
    appInspectorMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appListGtk.obj : \
    appListGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appListMotif.obj : \
    appListMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appMacPictPs.obj : \
    appMacPictPs.c \
    appFrameConfig.h \
    [-.appFrame]appMacPict.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMacPictX11.obj : \
    appMacPictX11.c \
    appFrameConfig.h \
    [-.appFrame]appMacPict.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMailDialog.obj : \
    appMailDialog.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]sioSmtp.h \
    [-.appUtil]appSystem.h

appMain.obj : \
    appMain.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appPaper.h \
    [-.appUtil]appGeoString.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMarginTool.obj : \
    appMarginTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]utilPropMask.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    appMarginTool.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appGeoString.h

appMenu.obj : \
    appMenu.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMenuGtk.obj : \
    appMenuGtk.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMenuMotif.obj : \
    appMenuMotif.c \
    appFrameConfig.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appMetricRuler.obj : \
    appMetricRuler.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appMetricRuler.h \
    [-.appFrame]appRuler.h \
    [-.appUtil]appUnit.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appOptionmenuGtk.obj : \
    appOptionmenuGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appOptionmenuMotif.obj : \
    appOptionmenuMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appPageLayoutTool.obj : \
    appPageLayoutTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]appGeoString.h \
    [-.appUtil]appUnit.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    appPageLayoutTool.h \
    [-.appUtil]appPaper.h \
    [-.appFrame]appPaperChooser.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appMarginTool.h

appPageTool.obj : \
    appPageTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appGeoString.h \
    [-.appUtil]appPaper.h \
    appPaperChooser.h \
    appMarginTool.h

appPaperChooser.obj : \
    appPaperChooser.c \
    appFrameConfig.h \
    [-.appUtil]appGeoString.h \
    [-.appUtil]appPaper.h \
    appPaperChooser.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appPrintDialog.obj : \
    appPrintDialog.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appUnit.h \
    [-.appUtil]appGeoString.h \
    appPaperChooser.h \
    [-.appUtil]appPaper.h

appPrintDocument.obj : \
    appPrintDocument.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appPaper.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appPutImageGtk.obj : \
    appPutImageGtk.c \
    appFrameConfig.h \
    appImage.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appPutImageMotif.obj : \
    appPutImageMotif.c \
    appFrameConfig.h \
    appImage.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appQuestion.obj : \
    appQuestion.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h

appReally.obj : \
    appReally.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appRuler.obj : \
    appRuler.c \
    appFrameConfig.h \
    [-.appUtil]appUnit.h \
    [-.appFrame]appRuler.h \
    [-.appFrame]appDraw.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appScrollDocument.obj : \
    appScrollDocument.c \
    appFrameConfig.h \
    [-.appUtil]appSystem.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appSpellTool.obj : \
    appSpellTool.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appSpellTool.h \
    [-.ind]ind.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.include]charnames.h

appSymbolPicker.obj : \
    appSymbolPicker.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appFrame]appSymbolPicker.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appEncodingMenu.h \
    [-.appFrame]appFrameConfig.h

appTextGtk.obj : \
    appTextGtk.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appTextMotif.obj : \
    appTextMotif.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appTextUtil.obj : \
    appTextUtil.c \
    appFrameConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]appGeoString.h

appTree.obj : \
    appTree.c \
    appFrameConfig.h \
    appTree.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appWinMeta.obj : \
    appWinMeta.c \
    appFrameConfig.h \
    [-.appFrame]appWinMeta.h \
    [-.appFrame]appGuiBase.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appWinMetaImg.obj : \
    appWinMetaImg.c \
    appFrameConfig.h \
    [-.appFrame]appWinMeta.h \
    [-.appFrame]appGuiBase.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appWinMetaPs.obj : \
    appWinMetaPs.c \
    appFrameConfig.h \
    [-.appFrame]appWinMeta.h \
    [-.appFrame]appGuiBase.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appWinMetaX11.obj : \
    appWinMetaX11.c \
    appFrameConfig.h \
    [-.appFrame]appWinMeta.h \
    [-.appFrame]appGuiBase.h \
    [-.bitmap]bitmap.h \
    [-.appUtil]sioGeneral.h \
    [-.bitmap]bmcolor.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]appGeo.h \
    [-.appFrame]appImage.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appXvCopyPaste.obj : \
    appXvCopyPaste.c \
    appFrameConfig.h \
    [-.appFrame]sioXprop.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appImage.h \
    [-.bitmap]bitmap.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appDraw.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appZoomMenu.obj : \
    appZoomMenu.c \
    appFrameConfig.h \
    [-.appFrame]appFrame.h \
    [-.appFrame]appGuiBase.h \
    [-.appFrame]appGuiResource.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]utilPrinter.h \
    [-.appUtil]utilMailContent.h \
    [-.appUtil]sioGeneral.h \
    [-.appFrame]appIcons.h \
    [-.appFrame]appTool.h \
    [-.appFrame]appDraw.h \
    [-.bitmap]bmcolor.h \
    [-.appFrame]appZoomMenu.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioCopyPasteGtk.obj : \
    sioCopyPasteGtk.c \
    appFrameConfig.h \
    [-.appFrame]sioXprop.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]sioMemory.h \
    [-.appUtil]utilMemoryBuffer.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioCopyPasteMotif.obj : \
    sioCopyPasteMotif.c \
    appFrameConfig.h \
    [-.appFrame]sioXprop.h \
    [-.appFrame]appGuiBase.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h
