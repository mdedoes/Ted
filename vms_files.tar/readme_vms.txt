
Jouk Jansen contrubited the following instructions based on his 
port of Ted 2.11 to OpenVMS.

Since then the source has evolved. Nevertheless I think that his 
excelent work can at least serve as an example for ports of future 
versions.

Apart from these instructions, Jouk Contributed <config.h> files 
and VMS style makefiles: "descrip.mms" files.

Though these files are probably obsoleted by changes to the source, they 
should be good starting point for future ports.

(MdD May 5, 2001)

>------------------------------------------------------------------------------<

  Compilation on VMS : type
	    $ MMS
	    in the main directory

  Installation on VMS : choose a directory where to install the Ted
	    distribution (i.e. disk:[editors.ted] )

	    define the logical TED$ROOT as follows
	       $ DEFINE/JOB/TRANS=(CONCEALED) TED$ROOT DISK:[EDITORS.TED.]
	    Note that the . before the ] is essential!!!

	    copy the file [.TEDPACKAGE]TEDBINDIST.TAR to
	    TED$ROOT:[000000]
	    Untar this file and set read-acess as required to all
	    the resulting files

	    define a "foreign" symbol 
	       ted :== $disk:[editors.ted_distribution.ted]ted
		       
  Notes about the VMS version VMS : This version was tested with
	    OpenVMS Alpha 7.3
	    Decwindows 1.2-6
	    Compaq C V6.5-001

>------------------------------------------------------------------------------<

  Jouk Jansen
		 
  joukj@hrem.stm.tudelft.nl

  Technische Universiteit Delft        tttttttttt  uu     uu  ddddddd
  Nationaal centrum voor HREM          tttttttttt  uu     uu  dd    dd
  Rotterdamseweg 137                       tt      uu     uu  dd     dd
  2628 AL Delft                            tt      uu     uu  dd     dd
  Nederland                                tt      uu     uu  dd    dd
  tel. 31-15-2781536                       tt       uuuuuuu   ddddddd

>------------------------------------------------------------------------------<

