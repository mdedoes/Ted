CC=cc/name=(as_is,short)\
	/include=([],[-.include],[-.appframe],[-.apputil],[-.bitmap],[-.ind])

OBS	=	\
		utilTree.obj,\
		utilTextAttribute.obj,\
		utilPs.obj,\
		utilPropMask.obj,\
		utilPrinter.obj,\
		utilPostscriptFontCatalog.obj,\
		utilPostscriptFace.obj,\
		utilMemoryBuffer.obj,\
		utilMatchFont.obj,\
		utilMD5.obj,\
		utilFontmap.obj,\
		utilFontEncoding.obj,\
		utilEndian.obj,\
		utilDate.obj,\
		utilCgiEcho.obj,\
		utilBase64.obj,\
		sioStdout.obj,\
		sioStdio.obj,\
		sioSmtp.obj,\
		sioQuotedPrintable.obj,\
		sioPfb.obj,\
		sioMsLz77.obj,\
		sioMemory.obj,\
		sioLzw.obj,\
		sioHttp.obj,\
		sioHex.obj,\
		sioGeneral.obj,\
		sioFork.obj,\
		sioFlate.obj,\
		sioEndian.obj,\
		sioDebug.obj,\
		sioCgiIn.obj,\
		sioBlocked.obj,\
		sioBase64.obj,\
		psGlyphs.obj,\
		psFont.obj,\
		docFont.obj,\
		appUrl.obj,\
		appUnit.obj,\
		appTagval.obj,\
		appSystem.obj,\
		appPaper.obj,\
		appGeoString.obj,\
		appGeo.obj,\
		appDebug.obj,\
		appCgiIn.obj

all : timestamp.vms [-.lib]apputil.olb
    write sys$output "all done in [.apputil]"

timestamp.vms : config.h_vms
	 copy config.h_vms appUtilConfig.h
	 open/write file timestamp.vms
	 close file

[-.lib]apputil.olb :	$(OBS)
	library/create apputil.olb $(OBS)
	rename apputil.olb [-.lib]

appCgiIn.obj : \
    appCgiIn.c \
    appUtilConfig.h \
    [-.appUtil]appCgiIn.h \
    [-.appUtil]appTagval.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appDebug.obj : \
    appDebug.c \
    appUtilConfig.h \
    [-.include]appDebug.h

appGeo.obj : \
    appGeo.c \
    appUtilConfig.h \
    appGeo.h \
    [-.appUtil]utilPropMask.h \
    utilPropMask.h

appGeoString.obj : \
    appGeoString.c \
    appUtilConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    appUnit.h \
    appGeoString.h

appPaper.obj : \
    appPaper.c \
    appUtilConfig.h \
    appPaper.h \
    appGeoString.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appSystem.obj : \
    appSystem.c \
    appUtilConfig.h \
    [-.appUtil]appSystem.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appTagval.obj : \
    appTagval.c \
    appUtilConfig.h \
    [-.appUtil]appTagval.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appUnit.obj : \
    appUnit.c \
    appUtilConfig.h \
    appUnit.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

appUrl.obj : \
    appUrl.c \
    appUtilConfig.h \
    [-.appUtil]appUrl.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

docFont.obj : \
    docFont.c \
    appUtilConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    utilPropMask.h \
    docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    utilFontEncoding.h

psFont.obj : \
    psFont.c \
    appUtilConfig.h \
    docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    psFont.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilFontEncoding.h \
    appSystem.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

psGlyphs.obj : \
    psGlyphs.c \
    appUtilConfig.h \
    psFont.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]charnames.h

sioBase64.obj : \
    sioBase64.c \
    appUtilConfig.h \
    sioBase64.h \
    [-.appUtil]sioGeneral.h \
    utilBase64.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioBlocked.obj : \
    sioBlocked.c \
    appUtilConfig.h \
    sioBlocked.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioCgiIn.obj : \
    sioCgiIn.c \
    appUtilConfig.h \
    [-.appUtil]sioCgiIn.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]appCgiIn.h \
    [-.appUtil]appTagval.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioDebug.obj : \
    sioDebug.c \
    appUtilConfig.h \
    sioDebug.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioEndian.obj : \
    sioEndian.c \
    appUtilConfig.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.appUtil]sioGeneral.h

sioFlate.obj : \
    sioFlate.c \
    appUtilConfig.h \
    sioFlate.h \
    [-.appUtil]sioGeneral.h \
    sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioFork.obj : \
    sioFork.c \
    appUtilConfig.h \
    sioFork.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioGeneral.obj : \
    sioGeneral.c \
    appUtilConfig.h \
    sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioHex.obj : \
    sioHex.c \
    appUtilConfig.h \
    sioHex.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioHttp.obj : \
    sioHttp.c \
    appUtilConfig.h \
    [-.appUtil]sioHttp.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]utilMemoryBuffer.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioLzw.obj : \
    sioLzw.c \
    appUtilConfig.h \
    sioLzw.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioMemory.obj : \
    sioMemory.c \
    appUtilConfig.h \
    [-.appUtil]sioMemory.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]utilMemoryBuffer.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioMsLz77.obj : \
    sioMsLz77.c \
    appUtilConfig.h \
    sioMsLz77.h \
    [-.appUtil]sioGeneral.h \
    sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioPfb.obj : \
    sioPfb.c \
    appUtilConfig.h \
    sioPfb.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioQuotedPrintable.obj : \
    sioQuotedPrintable.c \
    appUtilConfig.h \
    sioQuotedPrintable.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioSmtp.obj : \
    sioSmtp.c \
    appUtilConfig.h \
    [-.appUtil]sioSmtp.h \
    [-.appUtil]appSystem.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

sioStdio.obj : \
    sioStdio.c \
    appUtilConfig.h \
    [-.appUtil]sioStdio.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugoff.h \
    [-.include]appDebug.h

sioStdout.obj : \
    sioStdout.c \
    appUtilConfig.h \
    [-.appUtil]sioStdout.h \
    [-.appUtil]sioGeneral.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilBase64.obj : \
    utilBase64.c \
    utilBase64.h

utilCgiEcho.obj : \
    utilCgiEcho.c \
    [-.appUtil]utilCgiEcho.h \
    [-.appUtil]sioGeneral.h \
    [-.appUtil]appTagval.h \
    [-.appUtil]appCgiIn.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilDate.obj : \
    utilDate.c \
    [-.appUtil]utilDate.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilEndian.obj : \
    utilEndian.c \
    appUtilConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    utilEndian.h

utilFontEncoding.obj : \
    utilFontEncoding.c \
    appUtilConfig.h \
    utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilFontmap.obj : \
    utilFontmap.c \
    [-.appUtil]appUtilConfig.h \
    [-.appUtil]utilFontmap.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilMD5.obj : \
    utilMD5.c \
    utilMD5.h \
    [-.appUtil]appUtilConfig.h \
    utilBase64.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilMatchFont.obj : \
    utilMatchFont.c \
    appUtilConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    utilPropMask.h \
    docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    psFont.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilFontEncoding.h

utilMemoryBuffer.obj : \
    utilMemoryBuffer.c \
    appUtilConfig.h \
    [-.appUtil]utilMemoryBuffer.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilPostscriptFace.obj : \
    utilPostscriptFace.c \
    appUtilConfig.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilPostscriptFontCatalog.obj : \
    utilPostscriptFontCatalog.c \
    appUtilConfig.h \
    docFont.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]utilTextAttribute.h \
    psFont.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilFontEncoding.h \
    appSystem.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilPrinter.obj : \
    utilPrinter.c \
    appUtilConfig.h \
    utilPrinter.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilPropMask.obj : \
    utilPropMask.c \
    [-.appUtil]utilPropMask.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilPs.obj : \
    utilPs.c \
    appUtilConfig.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

utilTextAttribute.obj : \
    utilTextAttribute.c \
    appUtilConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    utilPropMask.h \
    utilTextAttribute.h \
    [-.appUtil]utilPropMask.h

utilTree.obj : \
    utilTree.c \
    utilTree.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h
