all :
	if f$search("lib.dir") .eqs. "" then create/directory [.lib]
	set default [.appframe]
	$(MMS)$(MMSQUALIFIERS)
	set default [-.apputil]
	$(MMS)$(MMSQUALIFIERS)
	set default [-.bitmap]
	$(MMS)$(MMSQUALIFIERS)
	set default [-.ind]
	$(MMS)$(MMSQUALIFIERS)
	set default [-.libreg]
	$(MMS)$(MMSQUALIFIERS)
	set default [-.ted]
	$(MMS)$(MMSQUALIFIERS)
