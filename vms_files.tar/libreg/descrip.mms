CC=cc/name=(as_is,short)\
	/include=([],[-.include],[-.appframe],[-.apputil],[-.bitmap],[-.ind])

OBS	=	\
		regsub.obj,\
		regexp.obj,\
		regerror.obj

all : timestamp.vms [-.lib]libreg.olb
    write sys$output "all done in [.libreg]"

timestamp.vms : config.h_vms
	 copy config.h_vms libregConfig.h
	 open/write file timestamp.vms
	 close file

[-.lib]libreg.olb :	$(OBS)
	library/create libreg.olb $(OBS)
	rename libreg.olb [-.lib]

regerror.obj : \
    regerror.c \
    libregConfig.h \
    [-.include]reg.h

regexp.obj : \
    regexp.c \
    libregConfig.h \
    [-.include]reg.h \
    regmagic.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

regsub.obj : \
    regsub.c \
    libregConfig.h \
    [-.include]reg.h \
    regmagic.h
