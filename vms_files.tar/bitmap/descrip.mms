CC=cc/name=(as_is,short)\
	/include=([],[-.include],[-.appframe],[-.apputil],[-.bitmap],[-.ind])

OBS	=	\
		bmxwd.obj,\
		bmxv.obj,\
		bmxpm.obj,\
		bmxbm.obj,\
		bmtiff.obj,\
		bmsqueeze.obj,\
		bmsgi.obj,\
		bmselect.obj,\
		bmreduce.obj,\
		bmpng.obj,\
		bmpgm.obj,\
		bmpcx.obj,\
		bmpalette.obj,\
		bmmapcolors.obj,\
		bmjpeg.obj,\
		bmio.obj,\
		bminvert.obj,\
		bmgif.obj,\
		bmgamma.obj,\
		bmformats.obj,\
		bmflip.obj,\
		bmfilter.obj,\
		bmfft.obj,\
		bmeps.obj,\
		bmdraw.obj,\
		bmconvert.obj,\
		bmcolor.obj,\
		bmbmp.obj,\
		bmalpha.obj,\
		bmadm.obj,\
		bm_gif_err.obj,\
		bm_egif_lib.obj,\
		bm_dgif_lib.obj,\
		bmSegments.obj

all : timestamp.vms [-.lib]bitmap.olb
    write sys$output "all done in [.bitmap]"

timestamp.vms : config.h_vms
	 copy config.h_vms bitmapConfig.h
	 open/write file timestamp.vms
	 close file

[-.lib]bitmap.olb :	$(OBS)
	library/create bitmap.olb $(OBS)
	rename bitmap.olb [-.lib]

bmSegments.obj : \
    bmSegments.c \
    bitmapConfig.h \
    bmSegments.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    bmintern.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bm_dgif_lib.obj : \
    bm_dgif_lib.c \
    bm_gif_lib.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    bm_gif_lib_private.h \
    [-.appUtil]sioBlocked.h \
    [-.appUtil]sioLzw.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bm_egif_lib.obj : \
    bm_egif_lib.c \
    bm_gif_lib.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    bm_gif_lib_private.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]sioBlocked.h \
    [-.appUtil]sioLzw.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h

bm_gif_err.obj : \
    bm_gif_err.c \
    bm_gif_lib.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h

bmadm.obj : \
    bmadm.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmalpha.obj : \
    bmalpha.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmbmp.obj : \
    bmbmp.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    bmp.h \
    [-.appUtil]sioHex.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.appUtil]sioStdio.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmcolor.obj : \
    bmcolor.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmconvert.obj : \
    bmconvert.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmdraw.obj : \
    bmdraw.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmeps.obj : \
    bmeps.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]utilPs.h \
    [-.appUtil]appGeo.h \
    [-.appUtil]utilPropMask.h \
    [-.appUtil]docFont.h \
    [-.appUtil]utilTextAttribute.h \
    [-.appUtil]psFont.h \
    [-.appUtil]utilFontEncoding.h \
    [-.appUtil]utilPostscriptFace.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmfft.obj : \
    bmfft.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmfilter.obj : \
    bmfilter.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmflip.obj : \
    bmflip.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmformats.obj : \
    bmformats.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmgamma.obj : \
    bmgamma.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmgif.obj : \
    bmgif.c \
    bitmapConfig.h \
    [-.appUtil]sioStdio.h \
    [-.appUtil]sioGeneral.h \
    bmintern.h \
    bitmap.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    bm_gif_lib.h

bminvert.obj : \
    bminvert.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmio.obj : \
    bmio.c \
    bitmapConfig.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmjpeg.obj : \
    bmjpeg.c \
    bitmapConfig.h \
    [-.appUtil]sioStdio.h \
    [-.appUtil]sioGeneral.h \
    bmintern.h \
    bitmap.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmmapcolors.obj : \
    bmmapcolors.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmpalette.obj : \
    bmpalette.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmpcx.obj : \
    bmpcx.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmpgm.obj : \
    bmpgm.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmpng.obj : \
    bmpng.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    [-.appUtil]sioStdio.h

bmreduce.obj : \
    bmreduce.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmselect.obj : \
    bmselect.c \
    bitmapConfig.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmsgi.obj : \
    bmsgi.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]utilEndian.h \
    [-.appUtil]sioStdio.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmsqueeze.obj : \
    bmsqueeze.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]sioHex.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.appUtil]sioStdio.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmtiff.obj : \
    bmtiff.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmxbm.obj : \
    bmxbm.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmxpm.obj : \
    bmxpm.c \
    bitmapConfig.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h

bmxv.obj : \
    bmxv.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]sioEndian.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h

bmxwd.obj : \
    bmxwd.c \
    bitmapConfig.h \
    bmintern.h \
    bitmap.h \
    [-.appUtil]sioGeneral.h \
    bmcolor.h \
    [-.appUtil]utilEndian.h \
    [-.include]appDebugon.h \
    [-.include]appDebug.h \
    XWDFile.h
